/*******************************************************************************
* Created by: Matthew Brean
* Created on: 2019-10-21
* Created for: ICS4U
* Daily Assignment: #3-02
* calculate factorials using recursion in functions
*******************************************************************************/
import java.util.Scanner;
public class FactorialRecursion{
    public static final int factorialF(int number){  
    	int answer;
    	if (number>1)
    		answer=number*factorialF(number-1);
    	else
    		answer=1;
    	return answer;}
	public static void main(String[] args){
		for(;;){//forever loop
		Scanner SCAN = new Scanner(System.in);
    	System.out.println("Number factorial: ");
		int factorial = SCAN.nextInt();
		System.out.println(factorialF(factorial));}}}